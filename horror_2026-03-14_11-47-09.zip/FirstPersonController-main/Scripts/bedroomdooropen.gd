extends "res://Scripts/interactable.gd"

@onready var anim = $AnimationPlayer
var opened = false

func interact():
	if opened:
		anim.play("Door_Close")
	else:
		anim.play("Door_Open")

	opened = !opened
