extends "res://Scripts/Player.gd"
@onready var ray = $Head/Camera3D/RayCast3D

func _process(_delta):
	if Input.is_action_just_pressed("interact"):
		if ray.is_colliding():
			var obj = ray.get_collider()

			if obj.has_method("interact"):
				obj.interact()
