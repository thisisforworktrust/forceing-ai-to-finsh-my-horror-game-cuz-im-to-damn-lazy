extends Node

signal objective_changed(text: String)

var completed_tasks: Dictionary = {}
var current_objective: String = ""

func complete(task_name: String) -> void:
	completed_tasks[task_name] = true

func is_done(task_name: String) -> bool:
	return completed_tasks.has(task_name)

func set_objective(text: String) -> void:
	current_objective = text
	objective_changed.emit(text)
