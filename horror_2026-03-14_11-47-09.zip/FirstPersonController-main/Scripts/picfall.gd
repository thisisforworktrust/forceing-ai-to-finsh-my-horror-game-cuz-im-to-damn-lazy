extends Area3D

@onready var anim = $"../AnimationPlayer"
@onready var sound = $AudioStreamPlayer3D


var triggered = false
func _ready():
	body_entered.connect(_on_body_entered)
	triggered = false
func _on_body_entered(body):
	if triggered:
		return
	if body is CharacterBody3D:
		print("pic fell")
		sound.play()
		anim.play("Fall")
		triggered = true
