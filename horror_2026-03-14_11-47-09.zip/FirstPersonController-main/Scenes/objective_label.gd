extends Label

func _ready() -> void:

	text = "Objective: " + TaskManager.current_objective

	TaskManager.objective_changed.connect(_on_objective_changed)

func _on_objective_changed(t: String) -> void:
	text = "Objective: " + t
