extends Area3D

@onready var sound: AudioStreamPlayer3D = $AudioStreamPlayer3D

var triggered: bool = false

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	TaskManager.set_objective("Check Who Is At The Door")

func _on_body_entered(body: Node) -> void:

	if triggered:
		return

	if not body is CharacterBody3D:
		return

	triggered = true

	if sound:
		sound.play()
